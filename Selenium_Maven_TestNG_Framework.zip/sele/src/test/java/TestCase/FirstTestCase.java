package TestCase;

import org.openqa.selenium.By;

import org.testng.annotations.Test;

import utilities.ReadXLSdata;

public class FirstTestCase extends base.BaseTest {
@Test(dataProviderClass =ReadXLSdata.class, dataProvider = "dataprovider")
	public void LoginTest(String phone_num) {
		System.out.println("This is the first test case");
		driver.findElement(By.linkText(loc.getProperty("login_click"))).click();
		driver.findElement(By.xpath(loc.getProperty("ph_num"))).sendKeys(phone_num);
		
	}
//@DataProvider(name = "data-provider")
//public Object[][] dataProviderMethod() {
//    return new Object[][] {
//        { "91530115330" },
//        { "0123456789" },
//        { "9851429812" }
//    };
//}
}