package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;


public class ReadXLSdata {
	
	@DataProvider(name = "dataprovider")
//for manual invocation of the method
//	public static void main(String[] args) throws EncryptedDocumentException, IOException {
//		// TODO Auto-generated method stub
//		ReadXLSdata red =new ReadXLSdata();
//		red.getData("login");
//
//	}
public String[][] getData(Method m) throws EncryptedDocumentException, IOException {
	
	String sheetName = m.getName();
	
	File f= new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\Testdata.xlsx");
	FileInputStream fis = new FileInputStream(f);
	Workbook wb = WorkbookFactory.create(fis);
	Sheet exellName=wb.getSheet(sheetName);
	
	int TotalRows = exellName.getLastRowNum()+1;	
	int TotalColumns = exellName.getRow(0).getLastCellNum();
	System.out.println("Total Rows: " + TotalRows);
	System.out.println("Total Columns: " + TotalColumns);
	
	DataFormatter df = new DataFormatter();
	
	String testData[][]= new String[TotalRows][TotalColumns];
	for (int i = 0; i < TotalRows; i++) {
		for (int j = 0; j < TotalColumns; j++) {
			testData[i][j] = df.formatCellValue(exellName.getRow(i).getCell(j));
			System.out.print(testData[i][j]);
		}
		System.out.println();
	}
	return testData;
    }
	
}

